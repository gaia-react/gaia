@test "foo" {
  echo "foo"
}
